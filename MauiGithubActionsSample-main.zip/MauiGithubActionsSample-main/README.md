Android Video: [![YouTube Video Views](https://img.shields.io/youtube/views/GQuQPm40kys?style=social)](https://youtu.be/GQuQPm40kys)

Windows Video: [![YouTube Video Views](https://img.shields.io/youtube/views/8lvdLa0v8zY?style=social)](https://www.youtube.com/watch?v=8lvdLa0v8zY&list=PLfbOp004UaYXl4_IUKO_Gz4zkovwTjcRL&index=5)

# .NET MAUI Github Actions Sample
 Sample repository to show you how to build your .NET MAUI app with GitHub actions for Android, iOS, macOS and Windows
